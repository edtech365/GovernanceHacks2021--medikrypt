<?php
    $host = 'localhost';
    $dbname = 'medikrypt';
    $username = 'root';
    $password = '';
?>