<?php
    class dbString{
        private $HOSTNAME = "127.0.0.1";
        private $USERNAME = "root";
        private $PASSWORD = "";
        private $DBNAME = "";

    }

?>