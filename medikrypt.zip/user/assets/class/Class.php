<?php

    class MyClass{
        private $name;
        private $group;


        public function getCName(){
            return $this->name;
        }
        public function getCGroup(){
            return $this->group;
        }

        public function setCName($name){
            $this->name = $name;
        }

        public function setCGroup($group){
            $this->group = $group;
        }
    }


?>