<?php

    //Users getter and setter method.
    class User{
        private $user_id;
        private $password;
        private $fullname;
        private $othername;
        private $dob;
        private $gender;
        private $soo;
        private $lga;
        private $sporthouse;
        private $religion;
        private $genotype;
        private $bloodgroup;
        private $admissionnumber;
        private $address;
        private $phone;
        private $email;
        private $residencetype;
        private $prevschoolname;
        private $prevschooldate;
        private $title;
        private $occupation;
        private $officeaddress;
        private $nextofkinname;
        private $nextofkinphone;
        private $academicqualification;
        private $gradelevel;



        public function getUserID(): String{return $this->user_id;}
        public function getPassword(): String{ return $this->password;}
        public function getFullname(){ return $this->fullname; }
        public function getOthername(){ return $this->othername; }
        public function getDob(){ return $this->dob; }
        public function getGender(){ return $this->gender; }
        public function getSoo(){ return $this->soo; }
        public function getLga(){ return $this->lga; }
        public function getSporthouse(){ return $this->sporthouse; }
        public function getReligion(){ return $this->religion; }
        public function getGenotype(){ return $this->genotype; }
        public function getBloodgroup(){ return $this->bloodgroup; }
        public function getAdmissionno(){ return $this->admissionnumber; }
        public function getAddress(){ return $this->address; }
        public function getPhone(){ return $this->phone; }
        public function getEmail(){ return $this->email; }
        public function getResidencetype(){ return $this->residencetype; }
        public function getPrevschname(){ return $this->prevschoolname; }
        public function getPrevschdate(){ return $this->prevschooldate; }
        public function getTitle(){ return $this->title; }
        public function getOccupation(){ return $this->occpuation; }
        public function getOfficeaddress(){ return $this->officeaddress; }
        public function getKinname(){ return $this->nextofkinname; }
        public function getKinphone(){ return $this->nextofkinphone; }
        public function getQualification(){ return $this->academicqualification; }
        public function getGrade(){ return $this->gradelevel; }


        public function setUserID($user_id){$this->user_id = $user_id;}
        public function setPassword($password){$this->password = $password;}
        public function setFullname($fullname){$this->$fullname = $fullname;}
        public function setOthername($othername){$this->othername = $othername;}
        public function setDob($dob){$this->dob = $dob;}
        public function setGender($gender){$this->gender = $gender;}
        public function setSoo($soo){$this->soo = $soo;}
        public function setLga($lga){$this->lga = $lga;}
        public function setSporthouse($sporthouse){$this->sporthouse = $sporthouse;}
        public function setReligion($religion){$this->religion = $religion;}
        public function setGenotype($genotype){$this->genotype = $genotype;}
        public function setBloodgroup($bloodgroup){$this->bloodgroup = $bloodgroup;}
        public function setAdmissionno($admissionnumber){$this->admissionnumber = $admissionnumber;}
        public function setAddress($address){$this->$address = $address;}
        public function setPhone($phone){$this->phone = $phone;}
        public function setEmail($email){$this->email = $email;}
        public function setResidencetype($residencetype){$this->residencetype = $residencetype;}
        public function setPrevschname($prevschoolname){$this->prevschoolname = $prevschoolname;}
        public function setPrevschdate($prevschooldate){$this->prevschooldate = $prevschooldate;}
        public function setTitle($title){$this->title = $title;}
        public function setOccupation($occupation){$this->occupation = $occupation;}
        public function setOfficeaddress($officeaddress){$this->officeaddress = $officeaddress;}
        public function setKinname($nextofkinname){$this->nextofkinname = $nextofkinname;}
        public function setKinphone($nextofkinphone){$this->nextofkinphone = $nextofkinphone;}
        public function setQualification($academicqualification){$this->academicqualification = $academicqualification;}
        public function setGrade($gradelevel){$this->gradelevel = $gradelevel;}
       

    }

?>