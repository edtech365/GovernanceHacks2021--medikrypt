<?php
    class Setup{

        private $file;
        private $name;
        private $abbr;
        private $email;
        private $phone;
        private $password;
        private $logo;
        private $section;
        private $term;
        private $year;
        private $address;


        public function check(){

            $rdata = $this->readFile();
            $json = json_decode($rdata);
            $data = (array) $json;
            return count($data);
        }
        public function checkup(){
            $this->setFile("./system/setup.json");
            return $this->check();
        }

        private function readFile(){
            $read = file_get_contents($this->getFile());
            return $read;
        }

        private function writeFile($data){
            if(file_put_contents("setup.json",$data)){
                return true;
            }
            return false;            
        }



        public function createProject($name, $abbr, $email, $phone, $password, $logo, $section){
            $this->name = $name;
            $this->abbr = $abbr;
            $this->email = $email;
            $this->phone = $phone;
            $this->password = $password;
            $this->setLogo($logo);
            $this->section = $section;
            $this->build();
        }

        public function setTerm($year, $term, $address){
            $this->year = $year;
            $this->term = $term;
            $this->address = $address;
            $this->addUp();
        }

        private function addUp(){
            $rdata = $this->readFile();
            $json = json_decode($rdata);
            $data = (array) $json;
            $data["year"] = $this->year;
            $data["term"] = $this->term;
            $data["address"] = $this->address;
            $this->writeFile(json_encode($data));
        }

        private function build(){
            $arr["name"] = $this->name;
            $arr["abbr"] = $this->abbr;
            $arr["email"] = $this->email;
            $arr["phone"] = $this->phone;
            $arr["password"] = $this->password;
            $arr["logo"] = $this->logo;
            $arr["section"] = $this->section;

            $json = json_encode($arr);
            echo ($this->writeFile($json))? 'Written': 'Not Written';
        }




        //Getter and Setter
        private function setFile($file){
            $this->file = $file;
        }

        public function getFile(){ 
            if(strlen(trim($this->file)) >= 3){
                return $this->file;
            }
            return "setup.json";
        }
        public function getName(){ return $this->name;}
        public function getAbbr(){ return $this->abbr;}
        public function getEmail(){ return $this->email;}
        public function getPhone(){ return $this->phone;}
        public function getPassword(){ return $this->password;}
        public function getLogo(){ return $this->logo;}
        public function getSection(){ return $this->section;}
        public function getYear(){ return $this->year;}
        public function getTerm(){ return $this->term;}
        public function getAddress(){ return $this->address;}

        private function setLogo($logo){
            $target_dir = "assets/uploads/img/";
            $ext = pathinfo(basename($logo["name"]),PATHINFO_EXTENSION);
            $filename = $target_dir. strtolower($this->getAbbr()).".".$ext;
            // Check if image file is a actual image or fake image
            $check = getimagesize($logo["tmp_name"]);
            if($check !== false) {
                // Check file size
                if ($logo["size"] < 204800) {
                    if (move_uploaded_file($logo["tmp_name"], "../".$filename)) {
                        $this->logo = $filename;
                        return true;
                    } else {
                        echo "Sorry, there was an error uploading your file.";
                    }
                }
            }
            $this->logo = "";
            // Check if file already exists
            // if (file_exists($target_file)) {
            //     echo "Sorry, file already exists.";
            //     $uploadOk = 0;
            // }
        }

        public function imgType($logo){
            $ext = strtolower(pathinfo(basename($logo),PATHINFO_EXTENSION));
            if($ext == "jpg" || $ext == "png" || $ext == "jpeg") {
                return true;
            }
            return false;
        }



        //Login and Forgot module
        public function isLogin($username, $password){
            if(strpos($username, "@") > 1 || strpos($username, ".com") > 4 ){
                $arr["email"] = $username;
            }else{
                $arr["phone"] = $username;
            }
            $arr["password"] = $password;
            return $this->sync($arr);
        }


        private function sync($query){
            $maCounta = 0;
            $this->setFile("./system/setup.json");
            $read = $this->readFile();
            $json = json_decode($read);
            $data = (array) $json;
            foreach ($query as $key => $value) {
                if(array_key_exists($key, $data)){
                    if($data[$key] == $value){
                        $maCounta++;
                    }
                }
            }
            $this->name = $data["name"];
            $this->abbr = $data["abbr"];
            $this->logo = $data["logo"];
            return ($maCounta==2)? true : false;
        }
    }


    // $new = new Setup();
    // echo $new->check();




?>