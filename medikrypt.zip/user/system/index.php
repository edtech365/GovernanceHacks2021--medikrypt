<?php
	// session_destroy();
	session_start();
	require_once("handler.php");
	$new = new Setup();
	if(isset($_POST["btnNext"])){
		if(isset($_FILES["logo"]) && strlen($_FILES["logo"]["name"]) >= 6){
			if($new->imgType($_FILES["logo"]["name"])){
				echo $new->createProject($_POST["name"],$_POST["abbr"],$_POST["email"],$_POST["phone"],$_POST["password"],$_FILES["logo"],$_POST["section"]);
			}else{
				echo '<script> alert("Oooooops! The only allowed image is either png, jpg or jpeg with maximum size 200KB "); </script>';
			}
			
		}
	}

	if(isset($_POST["btnFinish"])){

		echo $new->setTerm($_POST["year"], $_POST["term"], $_POST["address"]);
	}
	$size = $new->check();

	if($size == 0){
		$_SESSION["isFirst"] = true;
		$_SESSION["isSecond"] = false;
	}else if($size == 7){
		$_SESSION["isFirst"] = false;
		$_SESSION["isSecond"] = true;

	}else{
		header("location: ../");
	}
	echo $size;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>Running System Setup...</title>
		
		<!-- Favicon -->
        <link rel="shortcut icon" href="assets/img/favicon.png">
	
		<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,500;0,600;0,700;1,400&display=swap">

		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="../assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="../assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="../assets/css/style.css">
    </head>
    <body>
	
		<!-- Main Wrapper -->
        <div class="main-wrapper login-body">
            <div class="login-wrapper">
            	<div class="container">
                	<div class="loginbox" style="max-width: 400px;">
                        <div class="login-right" style="min-width: 100%;">
							<div class="login-right-wrap">
								<h1>Setup Page</h1>
								<p class="account-subtitle">Setup your dashboard <br> <sub> Version 1.0</sub> </p>
								
								<!-- Form 1 -->
								<form name="form" method="post" enctype="multipart/form-data" style=" display:<?php echo (isset($_SESSION["isFirst"]) && $_SESSION["isFirst"] == true )? "block": "none"; ?>">
									<div class="form-group">
										<input class="form-control" required name="name" type="text" placeholder="School name">
									</div>
									<div class="form-group">
										<input class="form-control" required name="abbr" type="text" placeholder="abbreviation  e.g KD">
									</div>
									<div class="form-group">
										<input class="form-control" required name="email" type="email" placeholder="Email">
									</div>
									<div class="form-group">
										<input class="form-control" required name="phone" type="text" placeholder="Phone">
									</div>
									<div class="form-group">
										<input class="form-control" required name="password" type="password" placeholder="Password">
									</div>
									<div class="form-group">
										<select class="form-control" required name="section" id="">
											<option value="">Select section</option>
											<option value="day">Day section</option>
											<option value="boarding">Boarding section</option>
											<option value="both">Day and Boarding section</option>
										</select>
									</div>
									<div class="form-group">
										<input class="form-control" required name="logo" accept="image/*" type="file">
									</div>
									<div class="form-group mb-0">
										<button class="btn btn-primary btn-block" name="btnNext" type="submit">Next</button>
									</div>
								</form>
								<!-- /Form -->

								<!-- Form 2 -->
								<form name="form2" method="post" style=" display:<?php echo (isset($_SESSION["isSecond"]) && $_SESSION["isSecond"] == true )? "block": "none"; ?>">
									<div class="form-group">
										<input class="form-control" type="text" maxlength="10" required name="year" placeholder="Enter Academic Year e.g 2020/2021">
									</div>
									<div class="form-group">
										<select class="form-control" required name="term">
											<option value="">Select a term</option>
											<option value="First">First Term</option>
											<option value="Second">Second Term</option>
											<option value="Third">Third Term</option>
										</select>
									</div>
									
									<div class="form-group">
										<textarea class="form-control" required name="address" cols="30" rows="2" placeholder="Enter School address *"></textarea>
									</div>
									<div class="form-group mb-0">
										<button class="btn btn-primary btn-block" name="btnFinish" type="submit">Finish</button>
									</div>
								</form>
								<!-- /Form -->
								
							</div>
                        </div>
					</div>
					<div class="text-center dont-have">Copyright © 2020 Giembs Academy. <br>Developed by <a href="https://giembs.com/academy">Giembs Consultancy</a></div>
					
                </div>
            </div>
        </div>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
        <script src="../assets/js/jquery-3.5.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/plugins/bootstrap/js/bootstrap.min.js"></script>
		
		<!-- Custom JS -->
		<script src="../assets/js/script.js"></script>
		
    </body>
</html>